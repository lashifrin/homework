INSERT INTO product (id, name, description) VALUES (1, 'Register', 'Candy Store Barber');
INSERT INTO product (id, name, description) VALUES (2, 'ATM', 'Cash Machine');
