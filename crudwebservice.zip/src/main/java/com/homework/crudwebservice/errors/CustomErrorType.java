package com.homework.crudwebservice.errors;


public class CustomErrorType
{
    public String error;

    public CustomErrorType(String error)
    {
        this.error = error;
    }
}
